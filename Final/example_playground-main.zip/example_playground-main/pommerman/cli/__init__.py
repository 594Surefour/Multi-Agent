'''CLI module entry point'''
from . import run_battle
